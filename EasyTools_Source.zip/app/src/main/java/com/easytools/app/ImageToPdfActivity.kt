package com.easytools.app
import android.content.ContentValues
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.easytools.app.databinding.ActivityImageToPdfBinding

class ImageToPdfActivity: AppCompatActivity() {
    private lateinit var b: ActivityImageToPdfBinding
    private val images=mutableListOf<Uri>()
    private val pick=registerForActivityResult(ActivityResultContracts.GetMultipleContents()){ u ->
        if(u.isNotEmpty()){ images.clear(); images.addAll(u); b.selectedCount.text="${u.size} image(s) selected"; b.createPdf.isEnabled=true }
    }
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivityImageToPdfBinding.inflate(layoutInflater);setContentView(b.root)
        b.back.setOnClickListener{finish()}; b.selectImages.setOnClickListener{pick.launch("image/*")}; b.createPdf.setOnClickListener{makePdf()}
    }
    private fun makePdf(){
        val d=PdfDocument()
        try {
            images.forEachIndexed { i,u ->
                val bmp=contentResolver.openInputStream(u)?.use{BitmapFactory.decodeStream(it)} ?: return@forEachIndexed
                val w=595f; val h=842f; val m=24f; val sc=minOf((w-2*m)/bmp.width,(h-2*m)/bmp.height)
                val dw=bmp.width*sc; val dh=bmp.height*sc
                val p=d.startPage(PdfDocument.PageInfo.Builder(w.toInt(),h.toInt(),i+1).create())
                p.canvas.drawColor(Color.WHITE)
                p.canvas.drawBitmap(bmp,null,RectF((w-dw)/2,(h-dh)/2,(w+dw)/2,(h+dh)/2),Paint(3))
                d.finishPage(p); bmp.recycle()
            }
            val name="EasyTools_${System.currentTimeMillis()}.pdf"
            val v=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"application/pdf");put(MediaStore.Downloads.IS_PENDING,1)}
            val out=contentResolver.insert(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),v)!!
            contentResolver.openOutputStream(out)!!.use{d.writeTo(it)}
            v.clear();v.put(MediaStore.Downloads.IS_PENDING,0);contentResolver.update(out,v,null,null)
            Toast.makeText(this,"PDF saved in Downloads",Toast.LENGTH_LONG).show()
        }catch(e:Exception){Toast.makeText(this,"Error: ${e.message}",Toast.LENGTH_LONG).show()}finally{d.close()}
    }
}