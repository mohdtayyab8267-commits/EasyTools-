package com.easytools.app
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.easytools.app.databinding.ActivityPremiumBinding

class PremiumActivity:AppCompatActivity(){
    private lateinit var b:ActivityPremiumBinding
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivityPremiumBinding.inflate(layoutInflater);setContentView(b.root);b.back.setOnClickListener{finish()};b.upgrade.setOnClickListener{b.status.text="Payment integration can be connected before Play Store release."}}
}