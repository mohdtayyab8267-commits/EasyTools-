package com.easytools.app
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.easytools.app.databinding.ActivityCompressImageBinding

class CompressImageActivity:AppCompatActivity(){
    private lateinit var b:ActivityCompressImageBinding
    private var uri:Uri?=null
    private val pick=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null){uri=u;b.fileName.text=u.lastPathSegment?:"Image selected";b.compress.isEnabled=true}}
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivityCompressImageBinding.inflate(layoutInflater);setContentView(b.root);b.back.setOnClickListener{finish()};b.select.setOnClickListener{pick.launch("image/*")};b.compress.setOnClickListener{compress()}}
    private fun compress(){
        try{
            val bmp=contentResolver.openInputStream(uri!!)?.use{BitmapFactory.decodeStream(it)}?:throw Exception("Cannot read image")
            val name="EasyTools_Compressed_${System.currentTimeMillis()}.jpg"
            val v=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"image/jpeg");put(MediaStore.Downloads.IS_PENDING,1)}
            val out=contentResolver.insert(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),v)!!
            contentResolver.openOutputStream(out)!!.use{bmp.compress(Bitmap.CompressFormat.JPEG,65,it)}
            v.clear();v.put(MediaStore.Downloads.IS_PENDING,0);contentResolver.update(out,v,null,null);bmp.recycle()
            Toast.makeText(this,"Compressed image saved in Downloads",Toast.LENGTH_LONG).show()
        }catch(e:Exception){Toast.makeText(this,"Error: ${e.message}",Toast.LENGTH_LONG).show()}
    }
}