package com.easytools.app
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.easytools.app.databinding.ActivityPdfToImageBinding
import java.io.File
import java.io.FileOutputStream

class PdfToImageActivity: AppCompatActivity(){
    private lateinit var b:ActivityPdfToImageBinding
    private var picked:Uri?=null
    private val pick=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null){picked=u;b.fileName.text=u.lastPathSegment?: "PDF selected";b.convert.isEnabled=true}}
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivityPdfToImageBinding.inflate(layoutInflater);setContentView(b.root);b.back.setOnClickListener{finish()};b.select.setOnClickListener{pick.launch("application/pdf")};b.convert.setOnClickListener{convert()}}
    private fun convert(){
        val u=picked?:return
        try{
            val pfd=contentResolver.openFileDescriptor(u,"r")?:throw Exception("Cannot open PDF")
            val r=PdfRenderer(pfd)
            for(i in 0 until r.pageCount){
                val page=r.openPage(i)
                val bmp=Bitmap.createBitmap(page.width*2,page.height*2,Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE);page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);page.close()
                val name="EasyTools_Page_${i+1}_${System.currentTimeMillis()}.jpg"
                val v=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"image/jpeg");put(MediaStore.Downloads.IS_PENDING,1)}
                val out=contentResolver.insert(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),v)!!
                contentResolver.openOutputStream(out)!!.use{bmp.compress(Bitmap.CompressFormat.JPEG,92,it)}
                v.clear();v.put(MediaStore.Downloads.IS_PENDING,0);contentResolver.update(out,v,null,null);bmp.recycle()
            }
            r.close();pfd.close();Toast.makeText(this,"Images saved in Downloads",Toast.LENGTH_LONG).show()
        }catch(e:Exception){Toast.makeText(this,"Error: ${e.message}",Toast.LENGTH_LONG).show()}
    }
}