package com.easytools.app
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.easytools.app.databinding.ActivityNotesBinding

class NotesActivity:AppCompatActivity(){
    private lateinit var b:ActivityNotesBinding
    private val prefs by lazy{getSharedPreferences("notes",MODE_PRIVATE)}
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivityNotesBinding.inflate(layoutInflater);setContentView(b.root);b.back.setOnClickListener{finish()};b.note.setText(prefs.getString("text",""));b.save.setOnClickListener{prefs.edit().putString("text",b.note.text.toString()).apply();b.status.text="Saved"}}
}