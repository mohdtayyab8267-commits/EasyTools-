package com.easytools.app
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.easytools.app.databinding.ActivityUnitConverterBinding
import kotlin.math.roundToInt

class UnitConverterActivity:AppCompatActivity(){
    private lateinit var b:ActivityUnitConverterBinding
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivityUnitConverterBinding.inflate(layoutInflater);setContentView(b.root);b.back.setOnClickListener{finish()};b.convert.setOnClickListener{convert()}}
    private fun convert(){
        val x=b.input.text.toString().toDoubleOrNull()?:return
        val type=b.type.selectedItemPosition
        val out=when(type){
            0->x*1000.0
            1->x*0.45359237
            2->(x-32)*5/9
            else->x*3.785411784
        }
        b.result.text="Result: ${((out*100000).roundToInt()/100000.0)}"
    }
}