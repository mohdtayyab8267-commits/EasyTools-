package com.easytools.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.easytools.app.databinding.ActivityMainBinding
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.android.libraries.ads.mobile.sdk.banner.AdView
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private var adView: AdView? = null

    companion object {
        // Google test Banner ID. Replace with your EasyTools_Banner ID before publishing.
        private const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/9214589741"
        private const val TAG = "EasyToolsAds"
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.imageToPdf.setOnClickListener { open(ImageToPdfActivity::class.java) }
        b.pdfToImage.setOnClickListener { open(PdfToImageActivity::class.java) }
        b.compressImage.setOnClickListener { open(CompressImageActivity::class.java) }
        b.qrScanner.setOnClickListener { open(QrScannerActivity::class.java) }
        b.unitConverter.setOnClickListener { open(UnitConverterActivity::class.java) }
        b.notes.setOnClickListener { open(NotesActivity::class.java) }
        b.premium.setOnClickListener { open(PremiumActivity::class.java) }

        initializeAds()
    }

    private fun initializeAds() {
        lifecycleScope.launch(Dispatchers.IO) {
            MobileAds.initialize(
                this@MainActivity,
                InitializationConfig.Builder("ca-app-pub-9913942897313621~685069482").build()
            ) {
                runOnUiThread { loadBannerAd() }
            }
        }
    }

    private fun loadBannerAd() {
        val container = b.adViewContainer
        val view = AdView(this)
        val widthDp = (container.width / resources.displayMetrics.density).toInt().coerceAtLeast(320)
        val adSize = AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, widthDp)
        view.adUnitId = BANNER_AD_UNIT_ID
        container.removeAllViews()
        container.addView(view)
        adView = view

        view.loadAd(
            BannerAdRequest.Builder(BANNER_AD_UNIT_ID, adSize).build(),
            object : AdLoadCallback<BannerAd> {
                override fun onAdLoaded(ad: BannerAd) {
                    Log.d(TAG, "Banner ad loaded")
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.w(TAG, "Banner ad failed: $adError")
                }
            }
        )
    }

    override fun onDestroy() {
        val view = adView
        if (view != null) {
            val parent = view.parent
            if (parent is android.view.ViewGroup) parent.removeView(view)
            view.destroy()
            adView = null
        }
        super.onDestroy()
    }

    private fun open(c: Class<*>) { startActivity(Intent(this, c)) }
}
